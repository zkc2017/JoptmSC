g++ clause.hpp clause.cpp hash_extend.h node.h node.cpp obtain_circuit_main.cpp target_functions.h target_functions.cpp simulation.h simulation.cpp -lz3 -o simulation
./simulation
